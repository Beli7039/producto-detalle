package shared;

public class Constants {
	public static String IMAGEN_PRODUCTO_DEFAULT="https://www.idelcosa.com/img/default.jpg";
}
