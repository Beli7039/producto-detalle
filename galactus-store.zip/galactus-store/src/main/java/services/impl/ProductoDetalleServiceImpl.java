package services.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import config.MyBatisUtil;
import dao.ProductoDetalleMapper;
import models.ProductoDetalle;
import services.ProductoDetalleService;

public class ProductoDetalleServiceImpl implements ProductoDetalleService{

	@Override
	public List<ProductoDetalle> listarDetalleProducto(Integer idProducto) {
		try {
			SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
			ProductoDetalleMapper productoDetalleMapper = session.getMapper(ProductoDetalleMapper.class);
			return productoDetalleMapper.listarProductosDetalle(idProducto);
		} catch (Exception e) {
			System.out.println("Error Detalle producto: "+e);
			return null;
		}
	}

}
