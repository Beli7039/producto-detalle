package services;

import java.util.List;


import models.ProductoDetalle;

public interface ProductoDetalleService {
	List<ProductoDetalle> listarDetalleProducto(Integer idProducto);
}
