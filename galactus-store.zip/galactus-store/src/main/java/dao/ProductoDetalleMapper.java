package dao;


import java.util.List;

import models.ProductoDetalle;

public interface ProductoDetalleMapper {
	List<ProductoDetalle> listarProductosDetalle(Integer idProducto);
}
