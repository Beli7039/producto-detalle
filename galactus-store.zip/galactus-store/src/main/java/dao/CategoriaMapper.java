package dao;

import java.util.List;
import models.Categoria;

public interface CategoriaMapper {
	List<Categoria> listarCategorias();
}
