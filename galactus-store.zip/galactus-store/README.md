# galactus-store
App creada con el grupo ed lenguaje de programacion java web sise

### Integrantes
- Diego Baes
- Juan Marquina

### Alcance - Explicacion del Proyecto
asdasd

### Diseño de la BD


### Link del video
https://youtu.be/iD1uJ0BRFD8